import React from 'react'

export default function page() {
  return (
    <div>dashboard default</div>
  )
}
